var Sylvester = {
  precision: 1e-6
};
